import config
import json

import sqlalchemydiff
import cx_Oracle

import warnings
warnings.filterwarnings("ignore")

import xlrd
from xlrd import open_workbook
import xlwt
from xlutils.copy import copy

import os.path

import excelgen

cx_Oracle.init_oracle_client(lib_dir=r"C:\oracle\instantclient_19_8")

# ***************************************************************************** #
# ***************************************************************************** #

def show_table_differences(output,sheet,wb): 
    row=1
    if "right_only" in output['tables']:
        # print("********** TABLES WHCIH ARE MISSING IN QA **********")
        # print(f"{output['tables']['right_only']}")
        sheet,wb = excelgen.get_excel_sheet('Table_Details',sheet,wb)
        row = excelgen.add_tbl_det_to_excel_report(output['tables']['right_only'],'Table missing',row,sheet,wb)
    if "left_only" in output['tables']:
        # print("********** TABLES WHCIH ARE MISSING IN DEV **********")
        # print(f"{output['tables']['left_only']}")
        sheet,wb = excelgen.get_excel_sheet('Table_Details',sheet,wb)
        row = excelgen.add_tbl_det_to_excel_report(output['tables']['left_only'],'Extra Table',row,sheet,wb)
    print('\n')

def show_column_differences(output,sheet,wb):
    row=1
    for tbl_nm in output['tables_data']:
        # print(f"KEY : {tbl_nm}")
        if "right_only" in output['tables_data'][tbl_nm]['columns']:
            # print(f"********** COLUMNS WHICH ARE MISSING IN QA EXISTING TABLES : [{tbl_nm}] **********")
            for y in output['tables_data'][tbl_nm]['columns']['right_only']:
                # print(f"COLUMN DETAILS : [{y['name']} {y['type']} nullable: {y['nullable']}]")
                col_nm = y['name']
                col_type = y['type']
                col_null = y['nullable']
                sheet,wb = excelgen.get_excel_sheet('Column_Details',sheet,wb)
                row = excelgen.add_col_det_to_excel_report(tbl_nm,col_nm,col_type,col_null,'Column Missing',row,sheet,wb)
                show_primarykey_differences(output,sheet,wb,row)

        if "left_only" in output['tables_data'][tbl_nm]['columns']:
            # print(f"********** COLUMNS WHICH ARE MISSING IN DEV EXISTING TABLE : [{tbl_nm}] **********")
            for x in output['tables_data'][tbl_nm]['columns']['left_only']:
                # print(f"COLUMN DETAILS : [{x['name']} {x['type']} nullable: {x['nullable']}]")
                col_nm = x['name']
                col_type = x['type']
                col_null = x['nullable']
                sheet,wb = excelgen.get_excel_sheet('Column_Details',sheet,wb)
                row = excelgen.add_col_det_to_excel_report(tbl_nm,col_nm,col_type,col_null,'Extra Column',row,sheet,wb)
                show_primarykey_differences(output,sheet,wb,row)
    print('\n')

def show_primarykey_differences(output,sheet,wb,row):
    for tbl_nm in output['tables_data']:
        # print(f"KEY : {tbl_nm}")
        if "primary_keys" in output['tables_data'][tbl_nm]:
            
            if "right_only" in output['tables_data'][tbl_nm]['primary_keys']:
                # print(f"********** PRIMARY KEY WHICH ARE MISSING IN QA TABLE : [{tbl_nm}] **********")
                for x in output['tables_data'][tbl_nm]['primary_keys']['right_only']:
                    # print(f"KEY COLUMN : [{x}]")
                    col_nm = x
                    col_type = ''
                    col_null = ''
                    sheet,wb = excelgen.get_excel_sheet('Column_Details',sheet,wb)
                    row = excelgen.add_col_det_to_excel_report(tbl_nm,col_nm,col_type,col_null,'Additional Primary Key',row,sheet,wb)

            if "left_only" in output['tables_data'][tbl_nm]['primary_keys']:
                # print(f"********** PRIMARY KEY WHICH ARE MISSING IN DEV TABLES : [{tbl_nm}] **********")
                for x in output['tables_data'][tbl_nm]['primary_keys']['left_only']:
                    # print(f"KEY COLUMN : [{x}]")
                    col_nm = x
                    col_type = ''
                    col_null = ''
                    sheet,wb = excelgen.get_excel_sheet('Column_Details',sheet,wb)
                    row = excelgen.add_col_det_to_excel_report(tbl_nm,col_nm,col_type,col_null,'Missing Primary Key',row,sheet,wb)
    print('\n')

def show_exist_col_differences(output,sheet,wb):
    # row=1
    for tbl_nm in output['tables_data']:
        # print(f"KEY : {tbl_nm}")
        # print(output['tables_data'][tbl_nm]['columns'])
        for a in output['tables_data'][tbl_nm]['columns']['diff']:
            # print(f"AAA {a}")
            if "right" in a:
                # print(f"********** COLUMNS DATA TYPE WHICH ARE MISSING IN QA EXISTING TABLES : [{tbl_nm}] **********")
                for y in output['tables_data'][tbl_nm]['columns']['diff']:
                    # print(f"COLUMN DETAILS : [{y['name']} {y['type']} nullable: {y['nullable']}]")
                    col_name = y['key']
                    right_type = y['right']['type']
                    right_nullable = y['right']['nullable']
                    right_default = y['right']['default']
                    right_autoincrement = y['right']['autoincrement']
                    right_comment = y['right']['comment']
            if "left" in a:
                # print(f"********** COLUMNS DATA TYPE WHICH ARE MISSING IN QA EXISTING TABLES : [{tbl_nm}] **********")
                for x in output['tables_data'][tbl_nm]['columns']['diff']:
                    # print(f"COLUMN DETAILS : [{y['name']} {y['type']} nullable: {y['nullable']}]")
                    left_type = x['left']['type']
                    left_nullable = x['left']['nullable']
                    left_default = x['left']['default']
                    left_autoincrement = x['left']['autoincrement']
                    left_comment = x['left']['comment']
            
            if right_type != left_type:
                print(f"Type mismatch {col_name} Need to change Type from {right_type} to {left_type}")
            elif right_nullable != left_nullable:
                print(f"Nullable missmatch {col_name} Need to change Type from {right_nullable} to {left_nullable}")
            elif right_default != left_default:
                print(f"Default missmatch {col_name} Need to change Type from {right_default} to {left_default}")
            elif right_autoincrement != left_autoincrement:
                print(f"auto increment missmatch {col_name} Need to change Type from {right_autoincrement} to {left_autoincrement}")
            elif right_comment != left_comment:
                print(f"Comment missmatch {col_name} Need to change Type from {right_comment} to {left_comment}")
    print('\n')

######################################################### MAIN
## Dev Engine
DEV_ENGINE_PATH_WIN_AUTH = f"oracle+cx_oracle://{config.dev_username}:{config.dev_password}@{config.dev_hostname}:{str(config.dev_port)}/?service_name={config.dev_sid}"

## QA Engine
QA_ENGINE_PATH_WIN_AUTH = f"oracle+cx_oracle://{config.qa_username}:{config.qa_password}@{config.qa_hostname}:{str(config.qa_port)}/?service_name={config.qa_sid}"

## Compare Two DB's
result = sqlalchemydiff.compare(QA_ENGINE_PATH_WIN_AUTH,DEV_ENGINE_PATH_WIN_AUTH)

if not result.is_match:
    output = result.errors
    # print(output)
    # print("********** Discrepencies Found.."'\n')
    # Create excel
    sheet,wb = excelgen.create_excel()
    sheet.write(2,0,'Thank You!!')
    sheet.write(3,0,'************************')
    sheet.write(4,0,'Sheet Details')
    sheet.write(5,0,'************************')
    sheet.write(6,0,'Table_Details')
    sheet.write(6,1,'Sheet contains list of tables which are missing or extra exists in Target Schema')
    sheet.write(7,0,'Column_Details')
    sheet.write(7,1,'Sheet contains list of columns which are missing or extra, Indexes/Primary/Foreign Keys which are missing')
    wb.save('DBCompareReport.xls')

    # show_table_differences(output,sheet,wb)
    
    # show_column_differences(output,sheet,wb)
    
    show_exist_col_differences(output,sheet,wb)
else:
    print("********** Wow.. No Discrepencies Found..")