from sqlalchemy import create_engine
from sqlalchemy import all_
import pandas as pd
import cx_Oracle
import config

cx_Oracle.init_oracle_client(lib_dir=r"C:\oracle\instantclient_19_8")

host=config.dev_hostname
port=config.dev_port
sid=config.dev_sid
user=config.dev_username
password=config.dev_password
sid = cx_Oracle.makedsn(host, port, sid=sid)

cstr = 'oracle://{user}:{password}@{sid}'.format(
    user=user,
    password=password,
    sid=sid
)

engine =  create_engine(
    cstr,
    convert_unicode=False,
    pool_recycle=10,
    pool_size=50,
    echo=True
)

result = engine.execute('select * from customers')

for row in result:
    print(row)