## Dev DB Details
dev_hostname = 'localhost'
dev_sid = 'XE'
dev_username = 'devuser'
dev_password = 'devuser'
dev_dsn = 'localhost/XE'
dev_port = 1521

## QA DB Details
qa_hostname = 'localhost'
qa_sid = 'XE'
qa_username = 'qauser'
qa_password = 'qauser'
qa_dsn = 'localhost/XE'
qa_port = 1521

## Meta DB Details
meta_hostname = 'localhost'
meta_sid = 'XE'
meta_username = 'c_metadata'
meta_password = 'c_metadata'
meta_dsn = 'localhost/XE'
meta_port = 1521