# from sqlalchemy.engine import MetaData, create_engine
from sqlalchemy import MetaData, create_engine
from sqlalchemy.engine import reflection
import sqlalchemydiff
import cx_Oracle
import config
import json

cx_Oracle.init_oracle_client(lib_dir=r"C:\oracle\instantclient_19_8")

## Dev Engine
DEV_ENGINE_PATH_WIN_AUTH = f"oracle+cx_oracle://{config.dev_username}:{config.dev_password}@{config.dev_hostname}:{str(config.dev_port)}/?service_name={config.dev_sid}"
dev_engine = create_engine(DEV_ENGINE_PATH_WIN_AUTH, max_identifier_length=128)
dev_conn = dev_engine.connect()

## QA Engine
QA_ENGINE_PATH_WIN_AUTH = f"oracle+cx_oracle://{config.qa_username}:{config.qa_password}@{config.qa_hostname}:{str(config.qa_port)}/?service_name={config.qa_sid}"
qa_engine = create_engine(QA_ENGINE_PATH_WIN_AUTH, max_identifier_length=128)
qa_conn = qa_engine.connect()

dev_insp = reflection.Inspector.from_engine(dev_engine)
qa_insp = reflection.Inspector.from_engine(qa_engine)

dev_tbl_list = dev_insp.get_table_names()
qa_tbl_list = qa_insp.get_table_names()

# print(f"DEV TABLES {dev_tbl_list}")
# print(f"QA TABLES {qa_tbl_list}")

# print(f"QA TABLES {qa_tbl_list[0]}")

result = sqlalchemydiff.compare(QA_ENGINE_PATH_WIN_AUTH,DEV_ENGINE_PATH_WIN_AUTH)
# print(result.is_match)

output = result.errors

# print(output)

# print(f"Tables which are present in DEV Database : {output['tables']['right_only']}")
# print(f"Tables which are present in QA Database : {output['tables']['left_only']}")

dev_conn.close()
qa_conn.close()