import warnings
warnings.filterwarnings("ignore")

import xlrd
from xlrd import open_workbook
import xlwt
from xlutils.copy import copy
import os.path
# ***************************************************************************** #


if os.path.isfile('test.xls'):
    print('old file')
    # book=open_workbook('test.xls')
    rb = xlrd.open_workbook('test.xls',formatting_info=True)
    wb = copy(rb)
    s_name = rb.sheet_names()
    if 'Table_Details' in s_name:
        print('Existing sheet')
        sheet = wb.get_sheet(-1)
        sheet.write(0,0,'EXISTING SHEET')
    else:
        print('New sheet')
        sheet = wb.add_sheet('Table_Details')
        sheet.write(0,0,'OLD SHEET')
else:
    print('new file')
    wb = xlwt.Workbook()
    sheet = wb.add_sheet('Column_Details')
    sheet.write(0, 0, 'NEW SHEET') 

wb.save('test.xls')