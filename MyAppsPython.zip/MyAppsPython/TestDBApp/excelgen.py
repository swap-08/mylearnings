import warnings
warnings.filterwarnings("ignore")

import xlrd
from xlrd import open_workbook
import xlwt
from xlutils.copy import copy
import os.path


# ***************************************************************************** #

def create_excel():
    if os.path.isfile('DBCompareReport.xls'):
        # print('old file')
        rb = xlrd.open_workbook('DBCompareReport.xls',formatting_info=True)
        wb = copy(rb)
        sheet = wb.get_sheet(0)
    else:
        # print('new file')
        wb = xlwt.Workbook()
        rb=''
        sheet = wb.add_sheet('Utility_Info', cell_overwrite_ok=True)
        sheet.write(0,0,'Schema Comparison Report') 
        sheet.write(1,0,'Owner: Swapnil Kadam')

    wb.save('DBCompareReport.xls')
    return sheet,wb

def get_excel_sheet(sheet_name,sheet,wb):
    rb = xlrd.open_workbook('DBCompareReport.xls',formatting_info=True)
    s_name = rb.sheet_names()
    # print(f"SHEET NAME {s_name}")
    if sheet_name in s_name:
        # print('Existing sheet')
        sheet = wb.get_sheet(-1)
    else:
        # print('New sheet')
        sheet = wb.add_sheet(sheet_name, cell_overwrite_ok=True)        
    return sheet,wb

def add_tbl_det_to_excel_report(data,msg,row,sheet,wb):
    # Workbook is created 
    sheet.write(0, 0, 'Table Name') 
    sheet.write(0, 1, 'Remark')
    for x in range(len(data)):
        sheet.write(row, 0, data[x].upper())
        sheet.write(row, 1,msg)
        row+=1
    wb.save('DBCompareReport.xls')
    return row

def add_col_det_to_excel_report(tbl_nm,col_nm,col_type,col_null,msg,row,sheet,wb):
    sheet.write(0, 0, 'Table Name')
    sheet.write(0, 1, 'Column Name') 
    sheet.write(0, 2, 'Data Type') 
    sheet.write(0, 3, 'Nullable')
    sheet.write(0, 4, 'Remark')
    sheet.write(row, 0, tbl_nm)
    sheet.write(row, 1, col_nm) 
    sheet.write(row, 2, col_type) 
    sheet.write(row, 3, col_null)
    sheet.write(row, 4, msg)
    row+=1
    wb.save('DBCompareReport.xls')
    return row