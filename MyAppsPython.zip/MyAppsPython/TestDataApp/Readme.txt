--Create virtual environment
py -m venv env

--Create requirements.txt file
pip freeze > requirements.txt

pip install pandas
pip install cx-Oracle
pip install sqlalchemy-diff


tnsfile
C:\app\admin\product\18.0.0\dbhomeXE\network\admin