import oradbcon
import pandas
import datacompy

meta_qry= """select 
                qry
                ,key_col 
        from test_query_details
        where del_dt is null
        """

df_meta_qry = pandas.read_sql(meta_qry, con=oradbcon.connect_to_meta_db())

for ind in df_meta_qry.index: 
    qry=df_meta_qry['QRY'][ind]
    join_col=df_meta_qry['KEY_COL'][ind]

    df_dev = pandas.read_sql(qry, con=oradbcon.connect_to_dev_db())
    df_qa = pandas.read_sql(qry, con=oradbcon.connect_to_qa_db())
    
    ## Comparison
    compare = datacompy.Compare(
    df_dev,
    df_qa,
    join_columns=join_col,  #You can also specify a list of columns eg ['policyID','statecode']
    abs_tol=0, #Optional, defaults to 0
    rel_tol=0, #Optional, defaults to 0
    df1_name='DEV', #Optional, defaults to 'df1'
    df2_name='QA' #Optional, defaults to 'df2'
    )
    print(compare.report())
    # abc=compare.column_stats
    # print(f"##### {abc}")
    
#     Write report in file
    file = open('test_report.xls','w') 
    file.write("This is the write command") 
    file.write("It allows us to write in a particular file") 
    file.write(compare.report(sample_count=1000)) 
    file.close()