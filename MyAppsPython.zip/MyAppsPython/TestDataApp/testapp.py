import oradbcon

########################################################### Connect to Meta

meta_db_con = oradbcon.connect_to_meta_db()
meta_cursor = meta_db_con.cursor()

meta_qry= """select 
                qry 
        from test_query_details
        where
                del_dt is null"""

meta_qry_res = meta_cursor.execute(meta_qry)

########################################################### Connect to DEV
dev_db_con = oradbcon.connect_to_dev_db()
dev_cursor = dev_db_con.cursor()

########################################################### Connect to QA
qa_db_con = oradbcon.connect_to_qa_db()
qa_cursor = qa_db_con.cursor()

 ########################################################### Fetch DEV and QA Data 
for meta_qry_data in meta_qry_res:
    # print(meta_qry_data[0])
    dev_qry_res = dev_cursor.execute(str(meta_qry_data[0]))
    qa_qry_res = qa_cursor.execute(str(meta_qry_data[0]))

    # print("******** Dev Data")
    # for dev_qry_data in dev_qry_res:
    #     print(dev_qry_data)

    # print("******** QA Data")
    # for qa_qry_data in qa_qry_res:
    #     print(qa_qry_data)
########################################################### Validate Data
    # if qa_qry_res == dev_qry_res:
    #     print("Success")
    # else:
    #     print("Fail")
    
    for qa_qry_data in qa_qry_res:
        if qa_qry_data in dev_qry_res:
            b=122
        else:
            print(qa_qry_data)

########################################################### Close all cursors

oradbcon.close_cursor(meta_cursor)
oradbcon.close_conn(meta_db_con)

oradbcon.close_cursor(dev_cursor)
oradbcon.close_conn(dev_db_con)

oradbcon.close_cursor(qa_cursor)
oradbcon.close_conn(qa_db_con)
