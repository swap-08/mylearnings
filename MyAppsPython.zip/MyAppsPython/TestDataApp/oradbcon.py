import cx_Oracle
import config

cx_Oracle.init_oracle_client(lib_dir=r"C:\oracle\instantclient_19_8")

def connect_to_dev_db():
    dev_connection = None
    print("******** Connecting to Dev Database....")
    try:
        dev_connection = cx_Oracle.connect(
            config.dev_username,
            config.dev_password,
            config.dev_dsn)

    except cx_Oracle.Error as error:
        print(f"ERROR : {error}")
    finally:
        return dev_connection

def connect_to_qa_db():
    qa_connection = None
    print("******** Connecting to QA Database....")
    try:
        qa_connection = cx_Oracle.connect(
            config.qa_username,
            config.qa_password,
            config.qa_dsn)

    except cx_Oracle.Error as error:
        print(f"ERROR : {error}")
    finally:
        return qa_connection

def connect_to_meta_db():
    qa_connection = None
    print("******** Connecting to Meta Database....")
    try:
        qa_connection = cx_Oracle.connect(
            config.meta_username,
            config.meta_password,
            config.meta_dsn)

    except cx_Oracle.Error as error:
        print(f"******** ERROR : {error}")
    finally:
        return qa_connection

def close_conn(connection):
    if connection:
        connection.close()
        print("******** Connection Close")

def close_cursor(cursor):
    if cursor:
        cursor.close()



