## Dev DB Details
dev_username = 'devuser'
dev_password = 'devuser'
dev_dsn = 'localhost/XE'
dev_port = 1512

## QA DB Details
qa_username = 'qauser'
qa_password = 'qauser'
qa_dsn = 'localhost/XE'
qa_port = 1512

## Meta DB Details
meta_username = 'c_metadata'
meta_password = 'c_metadata'
meta_dsn = 'localhost/XE'
meta_port = 1512